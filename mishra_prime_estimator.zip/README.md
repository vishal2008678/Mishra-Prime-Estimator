# Mishra Prime Estimator

A custom analytical formula created by Divya Prakash Mishra to estimate the nth prime number with high precision.

## 📌 Formula

Pn ≈ 1.165·n·log(n) − 0.18·log(n) + (n / 4.2·log(n)) − 0.62·sin(1.39·n) + ℜ(0.5·e^{inπ/4} + 0.35·e^{inπ/6})

## 📦 Usage (Python)
```python
from mishra_prime_estimator import mishra_prime_estimator
print(mishra_prime_estimator(1000))  # Estimate the 1000th prime
```

## 🔓 License
Distributed under the MIT License.