import math
import cmath

def mishra_prime_estimator(n):
    if n < 6:
        small_primes = [2, 3, 5, 7, 11]
        return small_primes[n - 1]
    
    term1 = 1.165 * n * math.log(n)
    term2 = -0.18 * math.log(n)
    term3 = (n / (4.2 * math.log(n)))
    term4 = -0.62 * math.sin(1.39 * n)
    complex_term = 0.5 * cmath.exp(1j * n * math.pi / 4) + 0.35 * cmath.exp(1j * n * math.pi / 6)
    
    prime_estimate = term1 + term2 + term3 + term4 + complex_term.real
    return round(prime_estimate)